package com.SICOIL.models;

public enum MovimientoTipo {
    ENTRADA,
    SALIDA
}
