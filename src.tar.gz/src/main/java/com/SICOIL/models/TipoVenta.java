package com.SICOIL.models;

public enum TipoVenta {
    CONTADO,
    CREDITO
}
