package com.SICOIL.models;

public enum CarteraMovimientoTipo {
    CREDITO,
    ABONO,
    AJUSTE
}
