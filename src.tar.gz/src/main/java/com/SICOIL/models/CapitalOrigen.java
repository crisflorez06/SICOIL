package com.SICOIL.models;

public enum CapitalOrigen {
    VENTA,
    COMPRA,
    INYECCION
}
