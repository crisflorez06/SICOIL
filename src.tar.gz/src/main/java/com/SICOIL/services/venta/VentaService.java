package com.SICOIL.services.venta;

import static com.SICOIL.services.venta.DetalleVentaSpecification.clienteNombreContains;
import static com.SICOIL.services.venta.DetalleVentaSpecification.productoNombreContains;
import static com.SICOIL.services.venta.DetalleVentaSpecification.tipoVentaEquals;
import static com.SICOIL.services.venta.DetalleVentaSpecification.ventaActivaEquals;
import static com.SICOIL.services.venta.DetalleVentaSpecification.usuarioNombreContains;
import static com.SICOIL.services.venta.DetalleVentaSpecification.ventaFechaBetween;

import com.SICOIL.dtos.venta.*;
import com.SICOIL.models.*;
import com.SICOIL.repositories.DetalleVentaRepository;
import com.SICOIL.mappers.venta.VentaMapper;
import com.SICOIL.repositories.VentaRepository;
import com.SICOIL.services.InventarioService;
import com.SICOIL.services.capital.CapitalService;
import com.SICOIL.services.cartera.CarteraService;
import com.SICOIL.services.cliente.ClienteService;
import com.SICOIL.services.producto.ProductoService;
import com.SICOIL.services.usuario.UsuarioService;
import jakarta.persistence.EntityNotFoundException;
import java.time.LocalDateTime;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.HttpStatus;

@Slf4j
@Service
@Transactional
@RequiredArgsConstructor
public class VentaService {

    private final VentaRepository ventaRepository;
    private final ProductoService productoService;
    private final DetalleVentaRepository detalleVentaRepository;
    private final UsuarioService usuarioService;
    private final ClienteService clienteService;
    private final VentaMapper ventaMapper;
    private final InventarioService inventarioService;
    private final CarteraService carteraService;
    private final CapitalService capitalService;

    public Page<VentaDetalleTablaResponse> traerTodos(Pageable pageable,
                                                      String nombreProducto,
                                                      String tipoVenta,
                                                      String nombreCliente,
                                                      String nombreUsuario,
                                                      Boolean activa,
                                                      LocalDateTime desde,
                                                      LocalDateTime hasta) {

        log.debug("Listando ventas filtros producto={}, tipoVenta={}, cliente={}, usuario={}, activa={}, desde={}, hasta={}",
                nombreProducto, tipoVenta, nombreCliente, nombreUsuario, activa, desde, hasta);

        TipoVenta filtroTipoVenta = parseTipoVenta(tipoVenta);

        Specification<DetalleVenta> spec = Specification
                .where(productoNombreContains(nombreProducto))
                .and(tipoVentaEquals(filtroTipoVenta))
                .and(ventaActivaEquals(activa))
                .and(clienteNombreContains(nombreCliente))
                .and(usuarioNombreContains(nombreUsuario))
                .and(ventaFechaBetween(desde, hasta));

        return detalleVentaRepository.findAll(spec, pageable).map(ventaMapper::toResponse);
    }


    @Transactional
    public VentaResponse crearVenta(VentaRequest request) {
        if (request == null || request.getItems() == null || request.getItems().isEmpty()) {
            throw new IllegalArgumentException("Debe enviar al menos un producto para crear la venta.");
        }

        Usuario usuario = usuarioService.obtenerUsuarioActual();

        Cliente cliente = clienteService.buscarPorId(request.getClienteId());

        Venta venta = ventaMapper.requestToEntity(request, usuario, cliente, productoService::buscarPorId);

        Venta guardada = ventaRepository.save(venta);
        log.info("Venta {} persistida, ajustando inventario", guardada.getId());
        ajustarInventarioPorVenta(guardada);
        if (guardada.getTipoVenta() == TipoVenta.CONTADO) {
            capitalService.registrarVentaContado(guardada);
        } else {
            capitalService.registrarVentaCredito(guardada);
        }
        carteraService.registrarVentaEnCartera(guardada);
        log.info("Venta {} creada con {} detalles", guardada.getId(), guardada.getDetalles().size());
        return ventaMapper.entityToResponse(guardada);
    }

    public VentaResponse anularVenta(Long ventaId, String razon) {
        if (ventaId == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Debe indicar el id de la venta a anular.");
        }
        if (razon == null || razon.isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Debe indicar el motivo de la anulación.");
        }

        Venta venta = ventaRepository.findById(ventaId)
                .orElseThrow(() -> new EntityNotFoundException("Venta no encontrada con ID: " + ventaId));

        if (!venta.isActiva()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "La venta ya se encuentra anulada.");
        }

        log.info("Revirtiendo inventario para venta {}", ventaId);
        revertirInventarioPorAnulacion(venta);

        Usuario usuarioActual = usuarioService.obtenerUsuarioActual();
        String motivo = "La venta fue anulada el " + LocalDateTime.now() +
                " por el usuario " + usuarioActual.getUsuario() +
                " por el siguiente motivo: " + razon.trim();

        venta.setActiva(false);
        venta.setMotivoAnulacion(motivo.trim());
        capitalService.revertirVenta(venta);

        carteraService.ajustarPorAnulacion(venta, usuarioActual, motivo);

        Venta actualizada = ventaRepository.save(venta);
        log.info("Venta {} anulada. Motivo: {}", actualizada.getId(), actualizada.getMotivoAnulacion());
        return ventaMapper.entityToResponse(actualizada);
    }

    private TipoVenta parseTipoVenta(String tipoVenta) {
        if (tipoVenta == null || tipoVenta.isBlank()) {
            return null;
        }
        try {
            return TipoVenta.valueOf(tipoVenta.toUpperCase());
        } catch (IllegalArgumentException ex) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "Tipo de venta inválido: " + tipoVenta, ex);
        }
    }

    private void ajustarInventarioPorVenta(Venta venta) {
        if (venta.getDetalles() == null) {
            return;
        }
        for (DetalleVenta detalle : venta.getDetalles()) {
            if (detalle == null) {
                continue;
            }
            Producto producto = detalle.getProducto();
            Integer cantidad = detalle.getCantidad();
            if (producto == null || producto.getId() == null || cantidad == null || cantidad <= 0) {
                continue;
            }
            String observacion = String.format("Venta #%d", venta.getId());
            log.debug("Registrando salida inventario por venta {} producto {} cantidad {}", venta.getId(), producto.getId(), cantidad);
            inventarioService.registrarSalida(producto.getId(), cantidad, observacion);
        }
    }

    private void revertirInventarioPorAnulacion(Venta venta) {
        if (venta.getDetalles() == null) {
            return;
        }
        for (DetalleVenta detalle : venta.getDetalles()) {
            if (detalle == null) {
                continue;
            }
            Producto producto = detalle.getProducto();
            Integer cantidad = detalle.getCantidad();
            if (producto == null || producto.getId() == null || cantidad == null || cantidad <= 0) {
                continue;
            }
            String observacion = String.format("Anulación venta #%d", venta.getId());
            log.debug("Registrando entrada inventario por anulación {} producto {} cantidad {}", venta.getId(), producto.getId(), cantidad);
            inventarioService.registrarMovimiento(producto.getId(), cantidad, observacion);
        }
    }
}
