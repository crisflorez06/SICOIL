package com.SICOIL.dtos.producto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProductosDesagrupadosResponse {
    private Long id;
    private Double precioCompra;
    private Integer stock;
}
