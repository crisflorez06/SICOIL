package com.SICOIL.repositories;

public interface ProductosSInPrecio {
    String getNombre();
    Integer getStockTotal();
    Integer getCantidadPorCajas();
}
