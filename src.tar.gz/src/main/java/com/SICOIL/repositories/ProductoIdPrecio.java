package com.SICOIL.repositories;

public interface ProductoIdPrecio {
    Long getId();
    Double getPrecioCompra();
}
